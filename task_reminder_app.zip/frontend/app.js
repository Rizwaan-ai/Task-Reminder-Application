const apiStatusEl = document.getElementById("api-status");
const remindersContainer = document.getElementById("reminders-container");
const emptyStateEl = document.getElementById("empty-state");
const reminderForm = document.getElementById("reminder-form");
const filterCategory = document.getElementById("filter-category");
const filterStatus = document.getElementById("filter-status");
const reminderTemplate = document.getElementById("reminder-card-template");

/**
 * Utility: format date to readable string
 */
function formatDate(dateStr) {
  const date = new Date(dateStr);
  if (Number.isNaN(date.getTime())) return "No due date";
  return date.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

/**
 * API helpers
 */
async function checkApi() {
  try {
    const res = await fetch(`${API_BASE}/health`);
    if (!res.ok) throw new Error("API not ok");
    apiStatusEl.textContent = "API connected";
    apiStatusEl.style.borderColor = "rgba(34,197,94,0.9)";
  } catch (err) {
    apiStatusEl.textContent = "API not reachable";
    apiStatusEl.style.borderColor = "rgba(248,113,113,0.9)";
  }
}

async function fetchReminders() {
  const cat = filterCategory.value;
  try {
    const url = new URL(`${API_BASE}/reminders`);
    if (cat && cat !== "all") {
      url.searchParams.set("category", cat);
    }
    const res = await fetch(url.toString());
    const data = await res.json();
    return data;
  } catch (err) {
    console.error("Error fetching reminders", err);
    return [];
  }
}

async function createReminder(payload) {
  const res = await fetch(`${API_BASE}/reminders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    const msg = data.error || "Failed to create reminder";
    alert(msg);
    throw new Error(msg);
  }
  return res.json();
}

async function toggleReminder(id) {
  const res = await fetch(`${API_BASE}/reminders/${id}/toggle`, {
    method: "PATCH",
  });
  return res.json();
}

async function deleteReminder(id) {
  const res = await fetch(`${API_BASE}/reminders/${id}`, {
    method: "DELETE",
  });
  return res.json();
}

/**
 * Render helpers
 */
function clearRemindersUI() {
  remindersContainer.innerHTML = "";
}

function applyFilters(reminders) {
  const statusFilter = filterStatus.value;
  if (statusFilter === "all") return reminders;
  if (statusFilter === "pending") {
    return reminders.filter((r) => !r.completed);
  }
  if (statusFilter === "completed") {
    return reminders.filter((r) => r.completed);
  }
  return reminders;
}

function renderReminders(reminders) {
  clearRemindersUI();
  const filtered = applyFilters(reminders);
  if (!filtered.length) {
    emptyStateEl.style.display = "block";
    return;
  }
  emptyStateEl.style.display = "none";

  filtered.forEach((reminder) => {
    const node = reminderTemplate.content.firstElementChild.cloneNode(true);
    const titleEl = node.querySelector(".reminder-title");
    const descEl = node.querySelector(".reminder-desc");
    const dueEl = node.querySelector(".reminder-due");
    const categoryBadge = node.querySelector(".badge-category");
    const statusBadge = node.querySelector(".badge-status");
    const toggleBtn = node.querySelector(".toggle-btn");
    const deleteBtn = node.querySelector(".delete-btn");

    titleEl.textContent = reminder.title;
    descEl.textContent = reminder.description || "No description provided.";
    dueEl.textContent = "Due: " + formatDate(reminder.dueDate);

    categoryBadge.textContent = reminder.category.toUpperCase();
    categoryBadge.classList.add(reminder.category);

    if (reminder.completed) {
      statusBadge.textContent = "Completed";
      statusBadge.classList.add("completed");
      toggleBtn.textContent = "Mark Pending";
      titleEl.style.textDecoration = "line-through";
      titleEl.style.opacity = "0.7";
    } else {
      statusBadge.textContent = "Pending";
      statusBadge.classList.add("pending");
      toggleBtn.textContent = "Complete";
    }

    toggleBtn.addEventListener("click", async () => {
      try {
        await toggleReminder(reminder._id);
        loadAndRender();
      } catch (err) {
        console.error(err);
      }
    });

    deleteBtn.addEventListener("click", async () => {
      if (!confirm("Delete this reminder?")) return;
      try {
        await deleteReminder(reminder._id);
        loadAndRender();
      } catch (err) {
        console.error(err);
      }
    });

    remindersContainer.appendChild(node);
  });
}

/**
 * Load reminders and render UI
 */
async function loadAndRender() {
  const reminders = await fetchReminders();
  renderReminders(reminders);
}

/**
 * Form submit handler
 */
reminderForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const formData = new FormData(reminderForm);
  const title = formData.get("title").trim();
  const description = formData.get("description").trim();
  const category = formData.get("category");
  const dueDate = formData.get("dueDate");

  if (!title || !category || !dueDate) {
    alert("Please fill in title, category and due date.");
    return;
  }

  const payload = { title, description, category, dueDate };

  const submitBtn = reminderForm.querySelector("button[type='submit']");
  submitBtn.disabled = true;
  submitBtn.textContent = "Adding...";

  try {
    await createReminder(payload);
    reminderForm.reset();
    loadAndRender();
  } catch (err) {
    console.error(err);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "Add Reminder";
  }
});

filterCategory.addEventListener("change", () => loadAndRender());
filterStatus.addEventListener("change", () => loadAndRender());

checkApi();
loadAndRender();