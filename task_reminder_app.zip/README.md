# Task / Reminder App

Simple full-stack Task/Reminder application:

- **Frontend**: HTML + CSS + Vanilla JavaScript
- **Backend**: Node.js + Express
- **Database**: MongoDB (works perfectly with MongoDB Compass)

## Features

- Add reminders with:
  - Title
  - Description
  - Category: `work`, `personal`, `urgent`
  - Due date (simple `<input type="date">`, no calendar graph library)
- View all reminders in a clean UI
- Filter by category and status (pending / completed)
- Toggle completed / pending
- Delete reminders
- API health check indicator

---

## How to Run (Step by Step)

### 1. Requirements

- Node.js installed
- MongoDB running locally
- MongoDB Compass (optional, for GUI view)

### 2. Backend Setup

```bash
cd backend
npm install
```

Create a file called `.env` in the `backend` folder (same place as `server.js`), based on `.env.example`:

```env
MONGO_URI=mongodb://127.0.0.1:27017/task_reminder_app
PORT=4000
```

Then start the backend:

```bash
npm start
```

You should see:

```text
✅ Connected to MongoDB
🚀 Server running on http://localhost:4000
```

### 3. Frontend Setup

Just open `frontend/index.html` in your browser.

> Tip: For best results, use a simple static server (VS Code Live Server extension, or `npx serve frontend`),  
> so that the browser treats it as a normal website.

The frontend expects the backend to be running at:

```text
http://localhost:4000/api
```

(You can change this URL in `frontend/index.html` if needed.)

---

## Using MongoDB Compass

1. Open MongoDB Compass.
2. Connect using the URI:

   ```text
   mongodb://127.0.0.1:27017
   ```

3. Open the database `task_reminder_app`.
4. Open the `reminders` collection to see all saved reminders.

---

## Project Structure

```text
task_reminder_app/
  backend/
    server.js
    package.json
    .env.example
    models/
      Reminder.js
  frontend/
    index.html
    style.css
    app.js
```

You can zip this whole `task_reminder_app` folder and submit it as your project.