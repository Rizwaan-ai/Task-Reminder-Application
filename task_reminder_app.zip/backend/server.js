require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/task_reminder_app";

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("✅ Connected to MongoDB");
  })
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err.message);
  });

// Reminder model
const Reminder = require("./models/Reminder");

// Routes

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "API is running" });
});

// Get all reminders
app.get("/api/reminders", async (req, res) => {
  try {
    const { category } = req.query;
    const filter = {};
    if (category && category !== "all") {
      filter.category = category;
    }
    const reminders = await Reminder.find(filter).sort({ dueDate: 1, createdAt: -1 });
    res.json(reminders);
  } catch (err) {
    console.error("Error fetching reminders:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// Create reminder
app.post("/api/reminders", async (req, res) => {
  try {
    const { title, description, category, dueDate } = req.body;

    if (!title || !category || !dueDate) {
      return res.status(400).json({ error: "Title, category, and due date are required" });
    }

    const reminder = new Reminder({
      title,
      description: description || "",
      category,
      dueDate,
    });

    const saved = await reminder.save();
    res.status(201).json(saved);
  } catch (err) {
    console.error("Error creating reminder:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// Update reminder
app.put("/api/reminders/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, category, dueDate, completed } = req.body;

    const updated = await Reminder.findByIdAndUpdate(
      id,
      { title, description, category, dueDate, completed },
      { new: true }
    );

    if (!updated) {
      return res.status(404).json({ error: "Reminder not found" });
    }

    res.json(updated);
  } catch (err) {
    console.error("Error updating reminder:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// Toggle complete
app.patch("/api/reminders/:id/toggle", async (req, res) => {
  try {
    const { id } = req.params;

    const reminder = await Reminder.findById(id);
    if (!reminder) {
      return res.status(404).json({ error: "Reminder not found" });
    }

    reminder.completed = !reminder.completed;
    const saved = await reminder.save();
    res.json(saved);
  } catch (err) {
    console.error("Error toggling reminder:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// Delete reminder
app.delete("/api/reminders/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await Reminder.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ error: "Reminder not found" });
    }

    res.json({ message: "Reminder deleted" });
  } catch (err) {
    console.error("Error deleting reminder:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// Serve frontend (optional: if you later build and move frontend here)
// const frontendPath = path.join(__dirname, "..", "frontend");
// app.use(express.static(frontendPath));

// app.get("*", (req, res) => {
//   res.sendFile(path.join(frontendPath, "index.html"));
// });

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});